from typing import TypeVar, ParamSpec

T = TypeVar("T")
E = TypeVar("E")
U = TypeVar("U")
F = TypeVar("F")

P = ParamSpec("P")

