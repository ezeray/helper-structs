# Package testing

The testing as of now is purely contained within docstring tests in the Result
class module.
